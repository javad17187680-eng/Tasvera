import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const MIME = {".html":"text/html; charset=utf-8",".css":"text/css",".js":"text/javascript",".json":"application/json",".png":"image/png",".svg":"image/svg+xml",".webp":"image/webp"};

function send(res, status, body, type="application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type":type,"Access-Control-Allow-Origin":"*"});
  res.end(typeof body === "string" ? body : JSON.stringify(body));
}
async function bodyJson(req) {
  let data=""; for await (const chunk of req) { data += chunk; if (data.length > 2_000_000) throw new Error("درخواست بیش از حد بزرگ است"); }
  return JSON.parse(data || "{}");
}
const server = http.createServer(async (req,res) => {
  if (req.method === "OPTIONS") return send(res,204,"");
  if (req.url === "/api/health") return send(res,200,{ok:true, app:"Tasvir AI Studio"});
  if (req.url === "/api/generate" && req.method === "POST") {
    try {
      const input = await bodyJson(req);
      const prompt = String(input.prompt || "").trim();
      if (!prompt) return send(res,400,{error:"توضیح تصویر را بنویس."});
      const apiUrl = process.env.IMAGE_API_URL;
      const apiKey = process.env.IMAGE_API_KEY;
      const model = process.env.IMAGE_MODEL || "";
      if (!apiUrl || !apiKey) return send(res,503,{error:"موتور تصویر هنوز تنظیم نشده است. راهنما را در README بخوان."});
      const upstream = await fetch(apiUrl, {
        method:"POST",
        headers:{"Authorization":`Bearer ${apiKey}`,"Content-Type":"application/json"},
        body:JSON.stringify({model, prompt, n:1, size:input.size || "1024x1024"})
      });
      const raw = await upstream.text();
      let data; try { data=JSON.parse(raw); } catch { data={raw}; }
      if (!upstream.ok) return send(res,upstream.status,{error:"موتور تصویر خطا داد.",details:data});
      return send(res,200,{ok:true,data});
    } catch (e) { return send(res,500,{error:e.message || "خطای سرور"}); }
  }
  const clean = req.url === "/" ? "/index.html" : decodeURIComponent(req.url.split("?")[0]);
  const full = path.join(__dirname,"public",clean);
  if (!full.startsWith(path.join(__dirname,"public"))) return send(res,403,{error:"Forbidden"});
  fs.readFile(full,(err,data)=>{
    if(err) return send(res,404,{error:"Not found"});
    res.writeHead(200,{"Content-Type":MIME[path.extname(full)] || "application/octet-stream"});
    res.end(data);
  });
});
server.listen(PORT,()=>console.log(`Tasvir AI Studio: http://localhost:${PORT}`));