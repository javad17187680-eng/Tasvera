const promptEl=document.querySelector("#prompt"),button=document.querySelector("#generate"),message=document.querySelector("#message"),result=document.querySelector("#result"),output=document.querySelector("#output");
button.addEventListener("click",async()=>{
 const prompt=promptEl.value.trim(); if(!prompt){message.textContent="اول توضیح تصویر را بنویس.";promptEl.focus();return}
 button.disabled=true;button.textContent="در حال ساخت…";message.textContent="درخواست به موتور تصویر فرستاده می‌شود…";
 try{
  const r=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt,size:document.querySelector("#size").value})});
  const data=await r.json();if(!r.ok)throw new Error(data.error||"ساخت تصویر انجام نشد.");
  output.innerHTML="";
  const item=data.data?.data?.[0];
  if(item?.url){const img=document.createElement("img");img.src=item.url;img.alt="تصویر تولیدشده";output.append(img)}
  else if(item?.b64_json){const img=document.createElement("img");img.src="data:image/png;base64,"+item.b64_json;img.alt="تصویر تولیدشده";output.append(img)}
  else {const pre=document.createElement("pre");pre.textContent=JSON.stringify(data.data,null,2);output.append(pre)}
  result.hidden=false;message.textContent="پاسخ موتور دریافت شد.";
 }catch(e){message.textContent=e.message}
 finally{button.disabled=false;button.innerHTML="<span>✦</span> ساخت تصویر"}
});
document.querySelector("#copyPrompt").addEventListener("click",async()=>{await navigator.clipboard.writeText(promptEl.value);message.textContent="توضیح تصویر کپی شد."});
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));